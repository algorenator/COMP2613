package example;

import example.data.OuterClass;

/**
 * Project: InnerClassExample
 * File: InnerClassExample.java
 * Date: Jan 31, 2012
 * Time: 7:50:36 PM
 */

/**
 * @author Chris Bensler, A00832188
 *
 */
public class InnerClassExample {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new InnerClassExample();
	}

	/**
	 * 
	 */
	@SuppressWarnings("unused")
	public InnerClassExample() {
		OuterClass.NestedClass nested = new OuterClass.NestedClass();
		// new OuterClass.InnerClass(); // invalid
		OuterClass outer = new OuterClass();
		outer.new InnerClass();
	}
}
