package example.data;
/**
 * Project: Test
 * File: OuterClass.java
 * Date: Jan 31, 2012
 * Time: 7:50:56 PM
 */

/**
 * @author Chris Bensler, A00832188
 *
 */
public class OuterClass {

	/**
	 * 
	 */
	public OuterClass() {
		System.out.println("OuterClass");
	}
	
	public static class NestedClass {
		public NestedClass() {
			System.out.println("NestedClass");
		}
		
	}

	public class InnerClass {
		public InnerClass() {
			System.out.println("InnerClass");
		}
	}
}
